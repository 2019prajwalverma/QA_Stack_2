from django.shortcuts import render
from .models import Destination
from django.views import View
import csv
# Create your views here.
# def home(request):
#     return render(request, 'home.html', {'name': 'Prajwal'})
class home(View):
    template_home = 'home.html'   
    def get(self, request):
        return render(request, self.template_home)

class answer(View):   
    template_answer = 'answer.html'
    result = []
    def get(self, request):
        return render(request, self.template_answer,{'result': self.result})
    def post(self, request):
        val1 = self.request.POST['answer']
        self.result.append(val1)
        return render(request, self.template_answer, {'result': self.result})

class answer1(View):   
    template_answer1 = 'answer1.html'
    result = []
    def get(self, request):
        return render(request, self.template_answer1,{'result': self.result})
    def post(self, request):
        val1 = self.request.POST['answer']
        self.result.append(val1)
        return render(request, self.template_answer1, {'result': self.result})


class answer2(View):   
    template_answer2 = 'answer2.html'
    result = []
    def get(self, request):
        return render(request, self.template_answer2,{'result': self.result})
    def post(self, request):
        val1 = self.request.POST['answer']
        self.result.append(val1)
        return render(request, self.template_answer2, {'result': self.result})

# ------------------------------------------------------------------------------------------------------
# class home(View):
#     template = 'home.html'
#     def get(self, request):
#         dest1 = Destination()
#         dest1.name = 'Mumbai'
#         dest1.desc = 'The City that never sleeps'
#         dest1.price = 700

#         return render(request, self.template, {'dest1':dest1} )

#     def post(self,request):

#         dest1 = Destination()
#         dest1.name = 'Mumbai'
#         dest1.desc = 'The City that never sleeps'
#         dest1.price = 700

#         val1 = int(self.request.POST['num1'])
#         val2 = int(self.request.POST['num2'])
#         res = val1 + val2
#         # forwording value of res to front end
#         return render(request, self.template, {'dest1':dest1, 'result': res})
#         # print (res)


# def home(request):
#     dest1 = Destination()
#     dest1.name = 'Mumbai'
#     dest1.desc = 'The City that never sleeps'
#     dest1.price = 700

#     val1 = int(request.POST['num1'])
#     val2 = int(request.POST['num2'])
#     res = val1 + val2

#     return render(request, 'home.html', {'dest1': dest1}, {'result':res})

# getting value from front-end and getting it inside Back-end
# def add(request):
#     val1 = int(request.POST['num1'])
#     val2 = int(request.POST['num2'])
#     res = val1 + val2
#     # forwording value of res to front end
#     return render(request, 'home.html', {'result': res})

# def index(request):
#     dest1 = Destination()
#     dest1.name = 'Mumbai'
#     dest1.desc = 'The City that never sleeps'
#     dest1.price = 700

#     return render(request, 'question.html', {'dest1': dest1})