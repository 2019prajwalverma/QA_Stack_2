from django.urls import path
from . import views
from stackapp.views import *

urlpatterns = [
    # FORMAT : path ('the_html_page you want to show', views.<method_name>, name='relevant_name')
    path('',home.as_view(), name='home' ),
    path('answer',answer.as_view(), name='answer'),
    path('answer1',answer1.as_view(), name='answer'),
    path('answer2',answer2.as_view(), name='answer')
    # path('home',views.add, name='add' ),
    # path('question', views.index, name='dynamic_value')
]