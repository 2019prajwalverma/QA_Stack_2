from django.db import models

# Create your models here.

class Destination:
    # defining variable
    id: int
    name: str 
    desc: str
    price: int

    